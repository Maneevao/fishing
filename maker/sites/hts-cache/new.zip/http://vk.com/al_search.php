<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<link rel="shortcut icon" href="/images/favicon_vk.ico?3" />

<link rel="apple-touch-icon" href="/images/safari_60.png">
<link rel="apple-touch-icon" sizes="76x76" href="/images/safari_76.png">
<link rel="apple-touch-icon" sizes="120x120" href="/images/safari_120.png">
<link rel="apple-touch-icon" sizes="152x152" href="/images/safari_152.png">

<meta http-equiv="content-type" content="text/html; charset=windows-1251" />
<meta name="description" content="" />

<title>People search results | VK</title>

<noscript><meta http-equiv="refresh" content="0; URL=/badbrowser.php"></noscript>

<script type="text/javascript">
var vk = {
  ads_rotate_interval: 120000,
  al: parseInt('4') || 4,
  id: 0,
  intnat: '1' ? true : false,
  host: 'vk.com',
  lang: 3,
  rtl: parseInt('') || 0,
  version: 18853,
  stDomains: 0,
  zero: false,
  contlen: 15589,
  loginscheme: 'https',
  ip_h: '37fe515d56cd7fc4c1',
  vc_h: 'd81667d4e8b5e93ce45364abd4ee3958',
  navPrefix: '/',
  dt: parseInt('0') || 0,
  fs: parseInt('11') || 11,
  ts: 1449228610,
  tz: 10800,
  pd: 0,
  pads: 1,
  vcost: 7,
  time: [2015, 12, 4, 14, 30, 10],
  sampleUser: -1, spentLastSendTS: new Date().getTime(),
}

window.locDomain = vk.host.match(/[a-zA-Z]+\.[a-zA-Z]+\.?$/)[0];
var _ua = navigator.userAgent.toLowerCase();
if (/opera/i.test(_ua) || !/msie 6/i.test(_ua) || document.domain != locDomain) document.domain = locDomain;
var ___htest = (location.toString().match(/#(.*)/) || {})[1] || '', ___to;
if (vk.al != 1 && ___htest.length && ___htest.substr(0, 1) == vk.navPrefix) {
  if (vk.al != 3 || vk.navPrefix != '!') {
    ___to = ___htest.replace(/^(\/|!)/, '');
    if (___to.match(/^([^\?]*\.php|login|mobile)([^a-z0-9\.]|$)/)) ___to = '';
    location.replace(location.protocol + '//' + location.host + '/' + ___to);
  }
}

var StaticFiles = {
  'common.js' : {v: 1129},
  'common.css': {v: 509},
  'ie6.css'   : {v: 26},
  'ie7.css'   : {v: 18}
  ,'lang3_0.js':{v:3534},'ui_controls.css':{v:66},'ui_controls.js':{v:187},'selects.js':{v:27},'search.js':{v:117},'search.css':{v:90}
}
</script>

<link rel="stylesheet" type="text/css" href="/css/al/common.css?509" />
<!--[if lte IE 6]><style type="text/css" media="screen">/* <![CDATA[ */ @import url(/css/al/ie6.css?26); /* ]]> */</style><![endif]-->
<!--[if IE 7]><style type="text/css" media="screen">/* <![CDATA[ */ @import url(/css/al/ie7.css?18); /* ]]> */</style><![endif]-->
<link type="text/css" rel="stylesheet" href="/css/ui_controls.css?66"></link><link type="text/css" rel="stylesheet" href="/css/al/search.css?90"></link><script type="text/javascript" src="/js/loader_nav18853_3.js"></script><script type="text/javascript" src="/js/al/common.js?1129_177"></script><script type="text/javascript" src="/js/lang3_0.js?3534"></script><link rel="alternate" media="only screen and (max-width: 640px)" href="http://m.vk.com/search" /><link rel="alternate" href="android-app://com.vkontakte.android/vkontakte/m.vk.com/search" /><meta name="msApplication-ID" content="C6965DD5.VK" /><meta name="msApplication-PackageFamilyName" content="C6965DD5.VK_v422avzh127ra" /><script type="text/javascript" src="/js/lib/ui_controls.js?187"></script><script type="text/javascript" src="/js/lib/selects.js?27"></script><script type="text/javascript" src="/js/al/search.js?117"></script>

</head>

<body onresize="onBodyResize()" class="is_rtl font_default pads ">
  <div id="system_msg" class="fixed"></div>
  <div id="utils"></div>

  <div id="layer_bg" class="fixed"></div><div id="layer_wrap" class="scroll_fix_wrap fixed"><div id="layer"></div></div>
  <div id="box_layer_bg" class="fixed"></div><div id="box_layer_wrap" class="scroll_fix_wrap fixed"><div id="box_layer"><div id="box_loader"><div class="loader"></div><div class="back"></div></div></div></div>

  <div id="stl_left"></div><div id="stl_side"></div>

  <script type="text/javascript">domStarted();</script>

  <div class="scroll_fix_wrap" id="page_wrap"><div id="reg_bar" class="top_info_wrap fixed">
  <div class="scroll_fix">
    <div id="reg_bar_content">
      Join VK now and always stay in contact with your friends and relatives
      <div class="button_blue" id="reg_bar_button"><a class="button_link" href="/join" onclick="return !showBox('join.php', {act: 'box', from: nav.strLoc}, {}, event)"><button id="reg_bar_btn"><span id="reg_bar_with_arr">Sign up</span></button></a></div>
    </div>
  </div>
</div>
<div><div class="scroll_fix">
  <div id="page_layout" style="width: 791px;">
    <div id="page_header" class="p_head1 p_head_l3">
      <div class="back"></div>
      <div class="left"></div>
      <div class="right"></div>
      <div class="content">
        <div id="top_nav" class="head_nav">
  <div id="top_logo_down" class="fl_l"></div>
  <a id="top_home_link" class="top_home_link fl_l" href="/" onmousedown="addClass('top_logo_down','tld_d');" onclick="return nav.go(this, event);"></a>
  <div id="top_links">
    <div class="fl_r" id="top_menu_wrap" style="">
      <a id="top_reg_link" class="fl_r top_nav_link" href="/join" style="" onclick="return !showBox('join.php', {act: 'box', from: nav.strLoc}, {}, event)" onmousedown="tnActive(this)">sign up</a>
      <a id="top_switch_lang" class="fl_r top_nav_link"  style="display: none;" onclick="ajax.post('al_index.php', {act: 'change_lang', lang_id: 3, hash: ''});" onmousedown="tnActive(this)">Switch to English</a>
    </div>
    <a class="fl_l top_nav_link" href="" id="top_back_link" onclick="return nav.go(this, event, {back: true})" onmousedown="tnActive(this)"></a>
  </div>
</div>
      </div>
    </div>

    <div id="side_bar" class="fl_l" style="">
      <div id="quick_login">
  <form method="POST" name="login" id="quick_login_form" action="https://login.vk.com/?act=login" onsubmit="if (vklogin) {return true} else {quick_login();return false;}">
    <input type="hidden" name="act" value="login" />
    <input type="hidden" name="role" value="al_frame" />
    <input type="hidden" name="expire" id="quick_expire_input" value="" />
    <input type="hidden" name="captcha_sid" id="quick_captcha_sid" value="" />
    <input type="hidden" name="captcha_key" id="quick_captcha_key" value="" />
    <input type="hidden" name="_origin" value="http://vk.com" />
    <input type="hidden" name="ip_h" value="37fe515d56cd7fc4c1" />
    <input type="hidden" name="lg_h" value="0b4c7e83c68018e83c" />
    <div class="label">Phone or email</div>
    <div class="labeled"><input type="text" name="email" class="text" id="quick_email" /></div>
    <div class="label">Password</div>
    <div class="labeled"><input type="password" name="pass" class="text" id="quick_pass" onkeyup="toggle('quick_expire', !!this.value);toggle('quick_forgot', !this.value)" /></div>
    <input type="submit" class="submit" />
  </form>
  <button class="flat_button button_wide button_big" id="quick_login_button">Log in</button>
  <button class="flat_button button_wide button_big" id="quick_reg_button" style="" onclick="top.showBox('join.php', {act: 'box', from: nav.strLoc})">Sign up</button>
  <div class="clear forgot"><a id="quick_forgot" href="/restore" target="_top">Forgot your password?</a><div class="checkbox ta_l" id="quick_expire" onclick="checkbox(this);ge('quick_expire_input').value=isChecked(this)?1:'';"><div></div>Don&#39;t remember me</div></div>
</div>
    </div>

    <div id="page_body" class="fl_r" style="width: 631px;">
      <div id="header_wrap2">
        <div id="header_wrap1">
          <div id="header" style="display: none">
            <h1 id="title"></h1>
          </div>
        </div>
      </div>
      <div id="wrap_between"></div>
      <div id="wrap3"><div id="wrap2">
  <div id="wrap1">
    <div id="content"><div id="search_content">
  <div id="search_query_wrap" class="wide clear_fix">
  <div class="clear_fix">
    <div class="search_isearch fl_l" onclick="event.cancelBubble = true;">
      <div class="search_input_cont">
        <input type="text" class="text" id="search_query" placeholder="Start typing any name or word" autocomplete="off" value="" />
      </div>
    </div>
    <div id="search_query_reset" class="fl_l" ></div>
    <div id="search_query_progress" class="fl_l" ></div>
    <div class="fl_r search_submit">
      <button class="flat_button button_wide" id="search_submit" onclick="window.searcher.updResults(true);"/>Search</button>
    </div>
  </div>
  <div id="search_section_tabs" style="display: none;" class="clear_fix">
  <div id="search_people_tab" class="search_subtab1 fl_l active" onmousedown="return searcher.switchSection('people', {updateStats: cur.section === 'auto', tab: 1}, event);">
  <div class="search_subtab2">
    People
  </div>
</div><div id="search_communities_tab" class="search_subtab1 fl_l " onmousedown="return searcher.switchSection('communities', {updateStats: cur.section === 'auto', tab: 1}, event);">
  <div class="search_subtab2">
    Communities
  </div>
</div><div id="search_audio_tab" class="search_subtab1 fl_l " onmousedown="return searcher.switchSection('audio', {updateStats: cur.section === 'auto', tab: 1}, event);">
  <div class="search_subtab2">
    Music
  </div>
</div><div id="search_video_tab" class="search_subtab1 fl_l " onmousedown="return searcher.switchSection('video', {updateStats: cur.section === 'auto', tab: 1}, event);">
  <div class="search_subtab2">
    Videos
  </div>
</div>
</div>
  <div id="filters"></div>
</div>
<div id="search_auto_rows">
  
</div>
<div class="summary_wrap clear_fix">
  <div id="summary" class="summary">
    Popular users
  </div>
</div>
<div id="results_wrap" class="">
  <table id="search_table" class="search_table">
  <tr>
    <td id="results" class="results highlight people_results">
      <div class="people_row three_col_row clear_fix">
  <div class="img search_bigph_wrap fl_l" onmouseover="Searcher.bigphOver(this, 331844458)">
    <a href="/rjj" onclick="return nav.go(this, event);"><img class="search_item_img" src="http://cs624920.vk.me/v624920458/50e04/q5inwJv7_u8.jpg" /></a>
  </div>
  <div class="info fl_l">
    <div class="labeled name"><a href="/rjj" onclick="return nav.go(this, event);">Roy Jones Jr.</a><div class="search_verified" onmouseover="pageVerifiedTip(this, {mid: 331844458, s: 1})"></div></div>
  </div>
  
</div><div class="people_row three_col_row clear_fix">
  <div class="img search_bigph_wrap fl_l" onmouseover="Searcher.bigphOver(this, 269793053)">
    <a href="/freddurst" onclick="return nav.go(this, event);"><img class="search_item_img" src="http://cs621218.vk.me/v621218053/14e6/aF7Mu6bVHOE.jpg" /></a>
  </div>
  <div class="info fl_l">
    <div class="labeled name"><a href="/freddurst" onclick="return nav.go(this, event);">Fred Durst</a><div class="search_verified" onmouseover="pageVerifiedTip(this, {mid: 269793053, s: 1})"></div></div><div class="labeled ">Los Angeles, USA</div>
  </div>
  
</div>
    </td>
    <td id="filters_td" class="filters">
      <div id="search_filters">
        
  <form id="filter_form" name="filter_form">
    <input type="hidden" id="q" name="c[q]" value="" />
    <input type="hidden" id="section" name="c[section]" value="people" />
    <input type="hidden" id="c[sort]" name="c[sort]" value="" /><div class="noselect clear_fix filter_main " onselectstart="return false">
  <div class="text fl_l">Region</div>
</div><div class="inner_filter" id="region_filter">
  <div id="cCountry" class="control">
    <input id="country" name="c[country]" class="text" />
  </div>
  <div id="cCity" class="control" style="display: none">
    <input id="city" name="c[city]" class="text" />
  </div>
</div><div class="noselect clear_fix filter_main " onselectstart="return false">
  <div class="text fl_l">School</div>
</div><div class="inner_filter" id="school_filter">
  <div id="cSchool" class="control" style="">
    <input id="school" name="c[school]" class="text" />
  </div>
  <div id="cSchClass" class="control" style="display: none">
    <input id="schClass" name="c[school_class]" class="text" />
  </div>
  <div id="cSchYear" class="control" style="display: none;">
    <input id="schYear" name="c[school_year]" class="text" />
  </div>
  <div id="cSchSpec" class="control" style="display: none;">
   <input id="school_spec" name="c[school_spec]" class="text" value="" placeholder="Specialization"/>
  </div>
</div><div class="noselect clear_fix filter_main " onselectstart="return false">
  <div class="text fl_l">College or university</div>
</div><div class="inner_filter" id="uni_filter">
  <div id="cUniversity" class="control">
    <input id="university" name="c[university]" class="text" />
  </div>
  <div id="cFaculty" class="control" style="display: none">
    <input id="faculty" name="c[faculty]" class="text" />
  </div>
  <div id="cChair" class="control" style="display: none">
    <input id="chair" name="c[chair]" class="text" />
  </div>
  <div id="cUniYear" class="control" style="display: none;">
    <input id="uniYear" name="c[uni_year]" class="text" />
  </div>
  <div id="cEduForm" class="control" style="display: none">
    <input id="edu_form" name="c[edu_form]" class="text" />
  </div>
  <div id="cEduStatus" class="control" style="display: none">
    <input id="edu_status" name="c[edu_status]" class="text" />
  </div>
</div><div class="noselect clear_fix filter_main " onselectstart="return false">
  <div class="text fl_l">Age</div>
</div><div class="inner_filter" id="age_filter">
  <div id="cAge" class="control clear_fix">
    <div class="range_to fl_l">
      <input id="ageFrom" name="c[age_from]" class="text" value="" />
    </div>
    <div class="range_sep fl_l"> - </div>
    <div class="range_to fl_l">
      <input id="ageTo" name="c[age_to]" class="text" value="" />
    </div>
  </div>
</div><input type="hidden" id="c[sex]" name="c[sex]" value="" /><div class="noselect clear_fix filter_main sex" onselectstart="return false">
  <div class="text fl_l">Sex</div>
</div><div class="inner_filter">
  <div id="cSex" class="control">
    <div class="radiobtn " onclick="radiobtn(this, 1, 'sex'); cur.onSexChanged(1);"><div></div>Female</div>
    <div class="radiobtn " onclick="radiobtn(this, 2, 'sex'); cur.onSexChanged(2);"><div></div>Male</div>
    <div class="radiobtn on" onclick="radiobtn(this, 0, 'sex'); cur.onSexChanged(0);"><div></div>Any</div>
  </div>
</div><div class="noselect clear_fix filter_main " onselectstart="return false">
  <div class="text fl_l">Relationship status</div>
</div><div class="inner_filter" id="marital_filter">
  <div id="cStatus" class="control">
    <input id="status" name="c[status]" class="text" />
  </div>
  <input type="hidden" name="c[photo]" id="photo" value="1" />
  <input type="hidden" name="c[online]" id="online" value="0" />
</div><div class="noselect clear_fix filter_shut" onclick="searcher.toggleFilter(this, 'personalFilter');" onselectstart="return false">
 <div class="text fl_l">Personal</div>
 <div class="arrow fl_l"><div class="arrow_back"></div></div>
</div>
<div style="display: none" class="inner_filter" id="personalFilter">

<div id="cInterests" class="control" style="display:none">
 <input id="interests" name="c[interests]" class="text" value="" placeholder="Interests" />
</div>

<div id="cReligion" class="control">
 <input id="religion" name="c[religion]" class="text"  value="" placeholder="Religious views" />
</div>
<div id="cPersonalPriority" class="control">
 <input id="personal_priority" name="c[personal_priority]" class="text" />
</div>
<div id="cImportantInOthers" class="control">
 <input id="important_in_others" name="c[people_priority]" class="text" />
</div>
<div id="cSmoking" class="control">
 <input id="smoking" name="c[smoking]" class="text" />
</div>
<div id="cAlcohol" class="control">
 <input id="alcohol" name="c[alcohol]" class="text" />
</div>

</div><div class="noselect clear_fix filter_shut" onclick="searcher.toggleFilter(this, 'companyFilter');" onselectstart="return false">
 <div class="text fl_l">Company</div>
 <div class="arrow fl_l"><div class="arrow_back"></div></div>
</div>
<div style="display: none" class="inner_filter" id="companyFilter">
<div id="cCompany" class="control">
 <input id="company" name="c[company]" class="text" value="" placeholder="Company" />
</div>
<div id="cPosition" class="control">
 <input id="position" name="c[position]" class="text" value="" placeholder="Position" />
</div>
</div><div class="noselect clear_fix filter_shut" onclick="searcher.toggleFilter(this, 'militaryFilter');" onselectstart="return false">
 <div class="text fl_l">Military Service</div>
 <div class="arrow fl_l"><div class="arrow_back"></div></div>
</div>
<div style="display: none" class="inner_filter" id="militaryFilter">
<div id="cMilCountry" class="control">
<input id="milCountry" name="c[mil_country]" class="text" />
</div>
<div id="cMilUnit" class="control" style="display:none">
 <input id="milUnit" name="c[mil_unit]" class="text" />
</div>
<div id="cMilYearFrom" class="control">
 <input id="milYearFrom" name="c[mil_year_from]" class="text" />
</div>
</div><div class="noselect clear_fix filter_shut" onclick="searcher.toggleFilter(this, 'extra_filter');" onselectstart="return false">
  <div class="text fl_l">Extra options</div>
  <div class="arrow fl_l"><div class="arrow_back"></div></div>
</div><div style="display: none;" class="inner_filter" id="extra_filter">
  <div id="name_only_filter">
    <input type="hidden" name="c[name]" id="name" value="1" />
  </div>
  <div id="cHometown" class="control" style="display: none">
   <input id="hometown" name="c[hometown]" class="text" value="" placeholder="Hometown"/>
  </div>
  <div id="cBYear" class="control">
    <input id="bYear" name="c[byear]" class="text" />
  </div>
  <div id="cBMonth" class="control">
    <input id="bMonth" name="c[bmonth]" class="text" />
  </div>
  <div id="cBDay" class="control">
    <input id="bDay" name="c[bday]" class="text" />
  </div>
  <div id="cLang" class="control" style="display: none">
   <input id="lang" name="c[lang]" class="text" />
  </div>
  
</div>
  </form>
      </div>
    </td>
  </tr>
</table>
</div>
</div></div>
  </div>
</div></div>
    </div>

    <div id="footer_wrap" class="fl_r" style="width: 661px;">
      <div id="bottom_nav">
  <a class="bnav_a" href="/about">about</a>
  <a class="bnav_a" href="/support?act=home" onclick="return nav.go(this, event);" style="display: none;">help</a>
  <a class="bnav_a" href="/terms">terms</a>
  <a class="bnav_a" href="/people">people</a><a class="bnav_a" href="/communities">communities</a>
  <a class="bnav_a" href="/dev">developers</a>
</div>
<p id="footer">
  <div class="copy_lang"><a href="/about">VK</a> &copy; 2015 <a class="bnav_lang" onclick="ajax.post('al_index.php', {act: 'change_lang', lang_id: 3, hash: '5dccc60b57cc1ebda7'})">English</a><a class="bnav_lang" onclick="ajax.post('al_index.php', {act: 'change_lang', lang_id: 0, hash: '5dccc60b57cc1ebda7'})">�������</a><a class="bnav_lang" onclick="ajax.post('al_index.php', {act: 'change_lang', lang_id: 1, hash: '5dccc60b57cc1ebda7'})">���������</a><a class="bnav_lang" onclick="if (vk.al) { showBox('lang.php', {act: 'lang_dialog', all: 1}, {params: {dark: true, bodyStyle: 'padding: 0px'}, noreload: true}); } else { changeLang(1); } return false;">all languages �</a></div>
  
  <div>
    
    
  </div>
</p>
    </div>
    <div class="clear"></div>
  </div>
</div></div><noscript><div style="position:absolute;left:-10000px;">
<img src="//top-fwz1.mail.ru/counter?id=2579437;pid=0;js=na" style="border:0;" height="1" width="1" />
</div></noscript></div>
  <div class="progress" id="global_prg"></div>

  <script type="text/javascript">
    if (parent && parent != window && (browser.msie || browser.opera || browser.mozilla || browser.chrome || browser.safari || browser.iphone)) {
      document.getElementsByTagName('body')[0].innerHTML = '';
    } else {
      domReady();
      updateMoney(0);
gSearch.init();
if (window.qArr && qArr[5]) qArr[5] = [5, "by item", "", "goods", 0x00000100];
if (browser.iphone || browser.ipad || browser.ipod) {
  setStyle(bodyNode, {webkitTextSizeAdjust: 'none'});
}var qf = ge('quick_login_form'), ql = ge('quick_login'), qe = ge('quick_email'), qp = ge('quick_pass');
var qlb = ge('quick_login_button'), prgBtn = qlb;

var qinit = function() {
  setTimeout(function() {
    ql.insertBefore(ce('div', {innerHTML: '<iframe class="upload_frame" id="quick_login_frame" name="quick_login_frame"></iframe>'}), qf);
    qf.target = 'quick_login_frame';
  }, 1);
}

if (window.top && window.top != window) {
  window.onload = qinit;
} else {
  setTimeout(qinit, 0);
}

qf.onsubmit = function() {
  if (!ge('quick_login_frame')) return false;
  if (!trim(qe.value)) {
    notaBene(qe);
    return false;
  } else if (!trim(qp.value)) {
    notaBene(qp);
    return false;
  }
  lockButton(window.__qfBtn = prgBtn);
  prgBtn = qlb;
  clearTimeout(__qlTimer);
  __qlTimer = setTimeout(loginSubmitError, 30000);
  domFC(domPS(qf)).onload = function() {
    clearTimeout(__qlTimer);
    __qlTimer = setTimeout(loginSubmitError, 2500);
  }
  return true;
}

window.loginSubmitError = function() {
  showFastBox('Warning', 'Unable to complete encrypted authorization. This can happen if your date and time settings are not configured correctly on your system. Please check your date &amp; time settings and restart the browser.');
}
window.focusLoginInput = function() {
  scrollToTop(0);
  notaBene('quick_email');
}
window.changeQuickRegButton = function(noShow) {
  if (noShow) {
    hide('top_reg_link', 'quick_reg_button');
    show('top_search_link');
  } else {
    hide('top_search_link');
    show('top_reg_link', 'quick_reg_button');
  }
  toggle('top_switch_lang', noShow && window.langConfig && window.langConfig.id != 3);
}
window.submitQuickLoginForm = function(email, pass, opts) {
  setQuickLoginData(email, pass, opts);
  if (opts && opts.prg) prgBtn = opts.prg;
  if (qf.onsubmit()) qf.submit();
}
window.setQuickLoginData = function(email, pass, opts) {
  if (email !== undefined) ge('quick_email').value = email;
  if (pass !== undefined) ge('quick_pass').value = pass;
  var params = opts && opts.params || {};
  for (var i in params) {
    var el = ge('quick_login_' + i);
    if (el) {
      val(el, params[i]);
    } else {
      qf.appendChild(ce('input', {type: 'hidden', name: i, id: 'quick_login_' + i, value: params[i]}));
    }
  }
}

if (qlb) {
  qlb.onclick = function() { if (qf.onsubmit()) qf.submit(); };
}

if (browser.opera_mobile) show('quick_expire');

if (1) {
  hide('support_link_td');
}
var ts_input = ge('ts_input'), oldFF = browser.mozilla && parseInt(browser.version) < 8;
if (browser.mozilla && !oldFF) {
  setStyle(ts_input, {padding: (vk.rtl ? '3px 20px 6px 40px' : '3px 41px 6px 20px')});
}
placeholderSetup(ts_input, {back: false, reload: true});
if (browser.opera || browser.msie || browser.mozilla) {
  setStyle(ts_input, {padding: (vk.rtl ? '4px 20px 5px 40px' : '4px 41px 5px 20px')});
} else if (browser.chrome || browser.safari) {
  setStyle(ts_input, {padding: (vk.rtl ? '4px 21px 5px 40px' : '4px 40px 5px 21px')});
}

TopSearch.init();
if (browser.msie8 || browser.msie7) {
  var st = {border: '1px solid #a6b6c6'};
  if (hasClass(ge('ts_wrap'), 'vk')) {
    if (vk.rtl) st.left = '1px';
    else st.right = '0px';
  } else {
    if (vk.rtl) st.right = '146px';
    else st.left = '146px';
  }
  setStyle(ge('ts_cont_wrap'), st);
}
window.tsHintsEnabled = 1;;shortCurrency();
setTimeout(zNav.pbind({}, {queue:1}), 0);
handlePageParams({"id":0,"pads":1,"level":1,"loc":"?c%5Bsection%5D=people&section=people","wrap_page":1,"width":791,"width_dec":160,"width_dec_footer":130,"body_class":"is_rtl font_default pads ","counters":"","pvbig":0,"pvdark":1});addEvent(document, 'click', onDocumentClick);window.lang = extend(window.lang || {}, {
  search_back_to: 'Search Results',
  head_search: 'search',
  search_audio_added: 'Added',
  global_photo_full_size: 'View photos'
});
searcher.init({"section":"people","has_more":false,"offset":40,"q":""});var filterTypes = [[3,"By rating"],[1,"By date registered"]];
if (cur.sortDD) {
  re(cur.sortDD.container);
}
cur.sortDD = new DropdownMenu(filterTypes, {
  target: ge('search_sort_dd'),
  value: 3,
  fadeSpeed: 0,
  onSelect: function(event) {
    if (event) searcher.switchFilter('sort', event.target.index || 0);
  }
});cur.lang = extend(cur.lang || {}, []);var uiCountry, uiCity;
var cityFilterSelData = {"countries":[[1,"<b>Russia<\/b>"],[2,"Ukraine"],[3,"Belarus"],[4,"Kazakhstan"],[5,"Azerbaijan"],[6,"Armenia"],[7,"Georgia"],[8,"Israel"],[9,"USA"],[65,"Germany"],[11,"Kyrgyzstan"],[12,"Latvia"],[13,"Lithuania"],[14,"Estonia"],[15,"Moldova"],[16,"Tajikistan"],[17,"Turkmenistan"],[18,"Uzbekistan"],[30,"Afghanistan"],[21,"Albania"],[22,"Algeria"],[23,"American Samoa"],[26,"Andorra"],[25,"Angola"],[24,"Anguilla"],[27,"Antigua and Barbuda"],[28,"Argentina"],[29,"Aruba"],[19,"Australia"],[20,"Austria"],[31,"Bahamas"],[34,"Bahrain"],[32,"Bangladesh"],[33,"Barbados"],[36,"Belgium"],[35,"Belize"],[37,"Benin"],[38,"Bermuda"],[47,"Bhutan"],[40,"Bolivia"],[235,"Bonaire, Sint Eustatius and Saba"],[41,"Bosnia and Herzegovina"],[42,"Botswana"],[43,"Brazil"],[52,"British Virgin Islands"],[44,"Brunei Darussalam"],[39,"Bulgaria"],[45,"Burkina Faso"],[46,"Burundi"],[103,"C&#244;te d`Ivoire"],[91,"Cambodia"],[92,"Cameroon"],[10,"Canada"],[90,"Cape Verde"],[149,"Cayman Islands"],[213,"Central African Republic"],[214,"Chad"],[216,"Chile"],[97,"China"],[98,"Colombia"],[99,"Comoros"],[100,"Congo"],[101,"Congo, Democratic Republic"],[150,"Cook Islands"],[102,"Costa Rica"],[212,"Croatia"],[104,"Cuba"],[138,"Cura&#231;ao"],[95,"Cyprus"],[215,"Czech Republic"],[73,"Denmark"],[231,"Djibouti"],[74,"Dominica"],[75,"Dominican Republic"],[54,"East Timor"],[221,"Ecuador"],[76,"Egypt"],[166,"El Salvador"],[222,"Equatorial Guinea"],[223,"Eritrea"],[224,"Ethiopia"],[208,"Falkland Islands"],[204,"Faroe Islands"],[205,"Fiji"],[207,"Finland"],[209,"France"],[210,"French Guiana"],[211,"French Polynesia"],[56,"Gabon"],[59,"Gambia"],[60,"Ghana"],[66,"Gibraltar"],[71,"Greece"],[70,"Greenland"],[69,"Grenada"],[61,"Guadeloupe"],[72,"Guam"],[62,"Guatemala"],[63,"Guinea"],[64,"Guinea-Bissau"],[58,"Guyana"],[57,"Haiti"],[67,"Honduras"],[68,"Hong Kong"],[50,"Hungary"],[86,"Iceland"],[80,"India"],[81,"Indonesia"],[84,"Iran"],[83,"Iraq"],[85,"Ireland"],[147,"Isle of Man"],[88,"Italy"],[228,"Jamaica"],[229,"Japan"],[82,"Jordan"],[94,"Kenya"],[96,"Kiribati"],[105,"Kuwait"],[106,"Laos"],[109,"Lebanon"],[107,"Lesotho"],[108,"Liberia"],[110,"Libya"],[111,"Liechtenstein"],[112,"Luxembourg"],[116,"Macau"],[117,"Macedonia"],[115,"Madagascar"],[118,"Malawi"],[119,"Malaysia"],[121,"Maldives"],[120,"Mali"],[122,"Malta"],[125,"Marshall Islands"],[124,"Martinique"],[114,"Mauritania"],[113,"Mauritius"],[126,"Mexico"],[127,"Micronesia"],[129,"Monaco"],[130,"Mongolia"],[230,"Montenegro"],[131,"Montserrat"],[123,"Morocco"],[128,"Mozambique"],[132,"Myanmar"],[133,"Namibia"],[134,"Nauru"],[135,"Nepal"],[139,"Netherlands"],[143,"New Caledonia"],[142,"New Zealand"],[140,"Nicaragua"],[136,"Niger"],[137,"Nigeria"],[141,"Niue"],[148,"Norfolk Island"],[173,"North Korea"],[174,"Northern Mariana Islands"],[144,"Norway"],[146,"Oman"],[152,"Pakistan"],[153,"Palau"],[154,"Palestine"],[155,"Panama"],[156,"Papua New Guinea"],[157,"Paraguay"],[158,"Peru"],[206,"Philippines"],[159,"Pitcairn Islands"],[160,"Poland"],[161,"Portugal"],[162,"Puerto Rico"],[93,"Qatar"],[163,"R&#233;union"],[165,"Romania"],[164,"Rwanda"],[169,"S&#227;o Tom&#233; and Pr&#237;ncipe"],[172,"Saint Helena"],[178,"Saint Kitts and Nevis"],[179,"Saint Lucia"],[180,"Saint Pierre and Miquelon"],[177,"Saint Vincent and the Grenadines"],[167,"Samoa"],[168,"San Marino"],[170,"Saudi Arabia"],[176,"Senegal"],[181,"Serbia"],[175,"Seychelles"],[190,"Sierra Leone"],[182,"Singapore"],[234,"Sint Maarten"],[184,"Slovakia"],[185,"Slovenia"],[186,"Solomon Islands"],[187,"Somalia"],[227,"South Africa"],[226,"South Korea"],[232,"South Sudan"],[87,"Spain"],[220,"Sri Lanka"],[188,"Sudan"],[189,"Suriname"],[219,"Svalbard and Jan Mayen"],[171,"Swaziland"],[218,"Sweden"],[217,"Switzerland"],[183,"Syria"],[192,"Taiwan"],[193,"Tanzania"],[191,"Thailand"],[194,"Togo"],[195,"Tokelau"],[196,"Tonga"],[197,"Trinidad and Tobago"],[199,"Tunisia"],[200,"Turkey"],[151,"Turks and Caicos Islands"],[198,"Tuvalu"],[53,"US Virgin Islands"],[201,"Uganda"],[145,"United Arab Emirates"],[49,"United Kingdom"],[203,"Uruguay"],[48,"Vanuatu"],[233,"Vatican"],[51,"Venezuela"],[55,"Vietnam"],[202,"Wallis and Futuna"],[78,"Western Sahara"],[89,"Yemen"],[77,"Zambia"],[79,"Zimbabwe"]],"country":"","cities":[],"city":""};

selectsData.setCountries(cityFilterSelData.countries);
selectsData.setCities(cityFilterSelData.country[0], cityFilterSelData.cities);

uiCity = new CitySelect(ge('city'), ge('cCity'), {
  show: function(el) {
    slide_show(el);
    if (cur.onSearchStep) cur.onSearchStep();
  },
  hide: function(el) {
    slide_hide(el);
    if (cur.onSearchStep) cur.onSearchStep();
  },
  width: 150,
  city: cityFilterSelData.city,
  country: cityFilterSelData.country[0],
  introText: 'Enter a name',
  placeholder: 'Choose a city',
  zeroPlaceholder: true,
  placeholderColor: '#777',
  noResult: 'No such cities were found.',
  otherCity: 'Other city',
  maxItemsShown: function(query_length) {
    if (query_length > 6) {
      return 500;
    } else {
      return 350;
    }
  },
  onChange: searcher.updResults
});
cur.uiCity = uiCity;

uiCountry = new CountrySelect(ge('country'), ge('cCountry'), {
  show: slide_show,
  hide: slide_hide,
  width: 150,
  country: cityFilterSelData.country,
  placeholder: 'Choose a country',
  placeholderColor: '#777',
  autocomplete: 1,
  noDefaultCountry: 1,
  full_list: '',
  citySelect: uiCity,
  onChange: searcher.updResults
});
cur.uiCountry = uiCountry;var uiSchCountry, uiSchCity, uiSchool, uiSchYear, uiSchClass;
var schoolFilterSelData = {"country":"","city":"","school":"","school_class":0};

uiSchYear = new Dropdown(ge('schYear'), [[0,"Select year graduated"],"2022","2021","2020","2019","2018","2017","2016","2015","2014","2013","2012","2011","2010","2009","2008","2007","2006","2005","2004","2003","2002","2001","2000","1999","1998","1997","1996","1995","1994","1993","1992","1991","1990","1989","1988","1987","1986","1985","1984","1983","1982","1981","1980","1979","1978","1977","1976","1975","1974","1973","1972","1971","1970","1969","1968","1967","1966","1965","1964","1963","1962","1961","1960","1959","1958","1957","1956","1955","1954","1953","1952","1951","1950","1949","1948","1947","1946"], {
  width: 150,
  zeroPlaceholder: true,
  placeholderColor: '#777',
  selectedItems: '',
  onChange: searcher.updResults
});
uiSchClass = new ClassSelect(ge('schClass'), ge('cSchClass'), {
  show: slide_show,
  hide: slide_hide,
  width: 150,
  placeholder: 'Choose a class',
  zeroPlaceholder: true,
  placeholderColor: '#777',
  country: schoolFilterSelData.country[0],
  school: schoolFilterSelData.school,
  school_class: schoolFilterSelData.school_class,
  onChange: searcher.updResults
});
uiSchool = new SchoolHintSelect(ge('school'), ge('cSchool'), {
  show: slide_show,
  hide: slide_hide,
  width: 150,
  school: schoolFilterSelData.school,
  city: schoolFilterSelData.city[0],
  introText: 'Enter a name',
  disabledText: 'Select a city',
  introCountryText: 'Choose a country',
  placeholder: 'Choose a school',
  zeroPlaceholder: true,
  placeholderColor: '#777',
  noResult: 'No results found.',
  disableOnHide: true,
  forceEnableCustom: -1,
  classSelect: uiSchClass,
  schoolYearSelect: uiUniYear,
  onChange: function(value) {
    if (intval(value)) {
      slide_show('cSchYear');
    } else {
      slide_hide('cSchYear');
      uiSchYear.val(0);
    }
   searcher.updResults();
  }
});
if (cur.uiCountry) extend(cur.uiCountry.options, {
  schoolSelect: uiSchool,
  classSelect: uiSchClass
});
if (cur.uiCity) extend(cur.uiCity.options, {
  schoolSelect: uiSchool,
  classSelect: uiSchClass
});

legacyPlaceholderSetup('school_spec');
addEvent('school_spec', 'change keydown', searcher.onInputChange);var uiUniCountry, uiUniCity, uiUniversity, uiFaculty, uiChair, uiUniYear, uiEduStatus, uiEduForm;
var uniFilterSelData = {"country":"","city":"","university":0,"faculties":{"university":0,"completed_faculties":1,"faculties":[]},"faculty":0,"chairs":{"faculty":0,"completed_chairs":1,"chairs":[]},"chair":0,"form":0,"status":0};

selectsData.setUniversityInfo(uniFilterSelData.university, uniFilterSelData.faculties);
selectsData.setFacultyInfo(uniFilterSelData.faculty, uniFilterSelData.chairs);

uiUniYear = new Dropdown(ge('uniYear'), [[0,"Select year graduated"],"2022","2021","2020","2019","2018","2017","2016","2015","2014","2013","2012","2011","2010","2009","2008","2007","2006","2005","2004","2003","2002","2001","2000","1999","1998","1997","1996","1995","1994","1993","1992","1991","1990","1989","1988","1987","1986","1985","1984","1983","1982","1981","1980","1979","1978","1977","1976","1975","1974","1973","1972","1971","1970","1969","1968","1967","1966","1965","1964","1963","1962","1961","1960","1959","1958","1957","1956","1955","1954","1953","1952","1951","1950","1949","1948","1947","1946"], {
  width: 150,
  zeroPlaceholder: true,
  placeholderColor: '#777',
  selectedItems: '',
  onChange: searcher.updResults
});
uiEduForm = new EducationFormSelect(ge('edu_form'), ge('cEduForm'), {
  show: slide_show,
  hide: slide_hide,
  multiselect: false,
  visible: uniFilterSelData.form,
  zeroPlaceholder: true,
  placeholderColor: '#777',
  country: uniFilterSelData.country[0],
  university: uniFilterSelData.university,
  edu_form: uniFilterSelData.form,
  placeholder: 'Mode of study',
  width: 150,
  onChange: searcher.updResults
});
uiEduStatus = new EducationStatusSelect(ge('edu_status'), ge('cEduStatus'), {
  show: slide_show,
  hide: slide_hide,
  multiselect: false,
  visible: uniFilterSelData.status,
  zeroPlaceholder: true,
  placeholderColor: '#777',
  country: uniFilterSelData.country[0],
  university: uniFilterSelData.university,
  edu_status: uniFilterSelData.status,
  placeholder: 'Choose a status',
  width: 150,
  onChange: searcher.updResults
});
uiChair = new ChairSelect(ge('chair'), ge('cChair'), {
  show: slide_show,
  hide: slide_hide,
  width: 150,
  chair: uniFilterSelData.chair,
  faculty: uniFilterSelData.faculty,
  placeholder: 'Choose a study program',
  zeroPlaceholder: true,
  placeholderColor: '#777',
  forceEnableCustom: -1,
  onChange: searcher.updResults
});
uiFaculty = new FacultySelect(ge('faculty'), ge('cFaculty'), {
  show: slide_show,
  hide: slide_hide,
  width: 150,
  faculty: uniFilterSelData.faculty,
  university: uniFilterSelData.university,
  placeholder: 'Choose a department',
  zeroPlaceholder: true,
  placeholderColor: '#777',
  forceEnableCustom: -1,
  chairSelect: uiChair,
  onChange: searcher.updResults
});
uiUniversity = new UniversityHintSelect(ge('university'), ge('cUniversity'), {
  show: slide_show,
  hide: slide_hide,
  width: 150,
  showMax: 30,
  university: uniFilterSelData.university,
  country: uniFilterSelData.country[0],
  city: uniFilterSelData.city[0],
  introText: 'Enter a name',
  placeholder: 'Choose a university',
  zeroPlaceholder: true,
  placeholderColor: '#777',
  noResult: 'No results found.',
  // forceEnableCustom: -1,
  alwaysVisible: 1,
  facultySelect: uiFaculty,
  eduFormSelect: uiEduForm,
  eduStatusSelect: uiEduStatus,
  uniYearSelect: uiUniYear,
  onChange: function(value) {
    if (intval(value)) {
      slide_show('cUniYear');
    } else {
      slide_hide('cUniYear');
    }
   searcher.updResults();
  }
});
if (cur.uiCountry) extend(cur.uiCountry.options, {
  universitySelect: uiUniversity,
  eduFormSelect: uiEduForm,
  eduStatusSelect: uiEduStatus
});
if (cur.uiCity) extend(cur.uiCity.options, {
  universitySelect: uiUniversity
});function getAgeFromData(max) {
  max = parseInt(max);
  if (!max > 0) max = 80;
  return getRangeData(14, max, 1, 'from ', 'From');
}
function getAgeToData(min) {
  min = parseInt(min);
  if (!min > 0) min = 14;
  return getRangeData(min, 80, 1, 'to ', 'To');
}

function getRangeData(min, max, step, prefix, label) {
 if (min > max) return false;
 var ret = [[0, label]];
 if (step < 0) {
   for (var i = max; i >= min; i += step)
     ret.push([i, prefix + i]);
 } else if (step > 0) {
   for (var i = min; i <= max; i += step)
     ret.push([i, prefix + i]);
 }
 return ret;
}

var uiAgeFrom, uiAgeTo;

uiAgeFrom = new Dropdown(ge('ageFrom'), getAgeFromData(''), {
  zeroPlaceholder: true,
  placeholderColor: '#777',
  width: 70,
  selectedItem: '',
  onChange: function(value){
    uiAgeTo.setData(getAgeToData(value));
   searcher.updResults();
  }
});

uiAgeTo = new Dropdown(ge('ageTo'), getAgeToData(''), {
  zeroPlaceholder: true,
  placeholderColor: '#777',
  width: 70,
  selectedItem: '',
  onChange: function(value){
    uiAgeFrom.setData(getAgeFromData(value));
   searcher.updResults();
  }
});window.radioBtns['sex'] = {
  els: Array.prototype.slice.apply(geByClass('radiobtn', ge('cSex'))),
  val: 0
}
cur.onSexChanged = function(value) {
  ge('c[sex]').value = value;
  var selectedStatuses = cur.uiStatuses.val();
  var statusesData = (value == 1) ? cur.fmStatuses : cur.mStatuses;
  cur.uiStatuses.setData(statusesData);
  if (selectedStatuses) {
    cur.uiStatuses.clear();
    var arr = selectedStatuses.split(',');
    for (var i = 0; i < arr.length; i++) {
      cur.uiStatuses.selectItem(arr[i]);
    }
  }
  searcher.updResults();
}

var uiStatuses;

var mStatuses = [
  [0, 'Choose a status'],
  [1, 'Single'],
  [2, 'In a relationship'],
  [3, 'Engaged'],
  [4, 'Married'],
  [7, 'In love'],
  [5, 'It&#39;s complicated'],
  [6, 'Actively searching']
];
cur.mStatuses = mStatuses;

var fmStatuses = [
  [0, 'Choose a status'],
  [1, 'Single'],
  [2, 'In a relationship'],
  [3, 'Engaged'],
  [4, 'Married'],
  [7, 'In love'],
  [5, 'It&#39;s complicated'],
  [6, 'Actively searching']
];
cur.fmStatuses = fmStatuses;

uiStatuses = new Dropdown(ge('status'),
  '' == '1' ? fmStatuses : mStatuses, {
  zeroPlaceholder: true,
  placeholderColor: '#777',
  selectedItems: '',
  width: 150,
  onChange: searcher.updResults
});
cur.uiStatuses = uiStatuses;

var onlineCB = new Checkbox(ge('online'), {
  width: 150,
  label: 'Online now',
  onChange: searcher.updResults
});
var photoCB = new Checkbox(ge('photo'), {
  width: 150,
  label: 'With photo',
  onChange: searcher.updResults
});
setStyle(photoCB.container, {paddingTop: '5px'});var uiPersonalPriority, uiPeoplePriority, uiSmoking, uiAlcohol;

var lifePriorityData = [
  [0, 'Personal Priority'],
  [1, 'Family and children'],
  [2, 'Career and money'],
  [3, 'Entertainment and leisure'],
  [4, 'Science and research'],
  [5, 'Improving the world'],
  [6, 'Personal development'],
  [7, 'Beauty and art'],
  [8, 'Fame and influence']
];
var peoplePriorityData = [
  [0, 'Important in Others'],
  [1, 'Intellect and creativity'],
  [2, 'Kindness and honesty'],
  [3, 'Health and beauty'],
  [4, 'Wealth and influence'],
  [5, 'Courage and persistence'],
  [6, 'Humor and love for life']
];
var smokingData = [
  [0, 'Views on Smoking'],
  [1, 'Very negative'],
  [2, 'Negative'],
  [3, 'Compromisable'],
  [4, 'Neutral'],
  [5, 'Positive']
];
var alcoholData = [
  [0, 'Views on Alcohol'],
  [1, 'Very negative'],
  [2, 'Negative'],
  [3, 'Compromisable'],
  [4, 'Neutral'],
  [5, 'Positive']
];

uiPersonalPriority = new Dropdown(ge('personal_priority'), lifePriorityData, {
  zeroPlaceholder: true,
  placeholderColor: '#777',
  selectedItems: '',
  width: 150,
  onChange: searcher.updResults
});
uiPeoplePriority = new Dropdown(ge('important_in_others'), peoplePriorityData, {
  zeroPlaceholder: true,
  placeholderColor: '#777',
  selectedItems: '',
  width: 150,
  onChange: searcher.updResults
});
uiSmoking = new Dropdown(ge('smoking'), smokingData, {
  zeroPlaceholder: true,
  placeholderColor: '#777',
  selectedItems: '',
  width: 150,
  onChange: searcher.updResults
});
uiAlcohol = new Dropdown(ge('alcohol'), alcoholData, {
  zeroPlaceholder: true,
  placeholderColor: '#777',
  selectedItems: '',
  width: 150,
  onChange: searcher.updResults
});

legacyPlaceholderSetup('religion');
legacyPlaceholderSetup('interests');

addEvent('religion', 'blur', searcher.updResults);
addEvent('religion', 'keydown', function(event) {
  if (event.keyCode == KEY.ENTER) searcher.updResults(event);
});
  legacyPlaceholderSetup('company');
  legacyPlaceholderSetup('position');
  addEvent('company', 'blur', searcher.updResults);
  addEvent('company', 'keydown', function(event) {
    if (event.keyCode == KEY.ENTER) searcher.updResults(event);
  });
  addEvent('position', 'blur', searcher.updResults);
  addEvent('position', 'keydown', function(event) {
    if (event.keyCode == KEY.ENTER) searcher.updResults(event);
  });var uiMilCountry, uiMilUnit, uiMilYearFrom;
var milFiltersel_data = {"countries":[[1,"<b>Russia<\/b>"],[2,"Ukraine"],[3,"Belarus"],[4,"Kazakhstan"],[5,"Azerbaijan"],[6,"Armenia"],[7,"Georgia"],[8,"Israel"],[9,"USA"],[65,"Germany"],[11,"Kyrgyzstan"],[12,"Latvia"],[13,"Lithuania"],[14,"Estonia"],[15,"Moldova"],[16,"Tajikistan"],[17,"Turkmenistan"],[18,"Uzbekistan"],[30,"Afghanistan"],[21,"Albania"],[22,"Algeria"],[23,"American Samoa"],[26,"Andorra"],[25,"Angola"],[24,"Anguilla"],[27,"Antigua and Barbuda"],[28,"Argentina"],[29,"Aruba"],[19,"Australia"],[20,"Austria"],[31,"Bahamas"],[34,"Bahrain"],[32,"Bangladesh"],[33,"Barbados"],[36,"Belgium"],[35,"Belize"],[37,"Benin"],[38,"Bermuda"],[47,"Bhutan"],[40,"Bolivia"],[235,"Bonaire, Sint Eustatius and Saba"],[41,"Bosnia and Herzegovina"],[42,"Botswana"],[43,"Brazil"],[52,"British Virgin Islands"],[44,"Brunei Darussalam"],[39,"Bulgaria"],[45,"Burkina Faso"],[46,"Burundi"],[103,"C&#244;te d`Ivoire"],[91,"Cambodia"],[92,"Cameroon"],[10,"Canada"],[90,"Cape Verde"],[149,"Cayman Islands"],[213,"Central African Republic"],[214,"Chad"],[216,"Chile"],[97,"China"],[98,"Colombia"],[99,"Comoros"],[100,"Congo"],[101,"Congo, Democratic Republic"],[150,"Cook Islands"],[102,"Costa Rica"],[212,"Croatia"],[104,"Cuba"],[138,"Cura&#231;ao"],[95,"Cyprus"],[215,"Czech Republic"],[73,"Denmark"],[231,"Djibouti"],[74,"Dominica"],[75,"Dominican Republic"],[54,"East Timor"],[221,"Ecuador"],[76,"Egypt"],[166,"El Salvador"],[222,"Equatorial Guinea"],[223,"Eritrea"],[224,"Ethiopia"],[208,"Falkland Islands"],[204,"Faroe Islands"],[205,"Fiji"],[207,"Finland"],[209,"France"],[210,"French Guiana"],[211,"French Polynesia"],[56,"Gabon"],[59,"Gambia"],[60,"Ghana"],[66,"Gibraltar"],[71,"Greece"],[70,"Greenland"],[69,"Grenada"],[61,"Guadeloupe"],[72,"Guam"],[62,"Guatemala"],[63,"Guinea"],[64,"Guinea-Bissau"],[58,"Guyana"],[57,"Haiti"],[67,"Honduras"],[68,"Hong Kong"],[50,"Hungary"],[86,"Iceland"],[80,"India"],[81,"Indonesia"],[84,"Iran"],[83,"Iraq"],[85,"Ireland"],[147,"Isle of Man"],[88,"Italy"],[228,"Jamaica"],[229,"Japan"],[82,"Jordan"],[94,"Kenya"],[96,"Kiribati"],[105,"Kuwait"],[106,"Laos"],[109,"Lebanon"],[107,"Lesotho"],[108,"Liberia"],[110,"Libya"],[111,"Liechtenstein"],[112,"Luxembourg"],[116,"Macau"],[117,"Macedonia"],[115,"Madagascar"],[118,"Malawi"],[119,"Malaysia"],[121,"Maldives"],[120,"Mali"],[122,"Malta"],[125,"Marshall Islands"],[124,"Martinique"],[114,"Mauritania"],[113,"Mauritius"],[126,"Mexico"],[127,"Micronesia"],[129,"Monaco"],[130,"Mongolia"],[230,"Montenegro"],[131,"Montserrat"],[123,"Morocco"],[128,"Mozambique"],[132,"Myanmar"],[133,"Namibia"],[134,"Nauru"],[135,"Nepal"],[139,"Netherlands"],[143,"New Caledonia"],[142,"New Zealand"],[140,"Nicaragua"],[136,"Niger"],[137,"Nigeria"],[141,"Niue"],[148,"Norfolk Island"],[173,"North Korea"],[174,"Northern Mariana Islands"],[144,"Norway"],[146,"Oman"],[152,"Pakistan"],[153,"Palau"],[154,"Palestine"],[155,"Panama"],[156,"Papua New Guinea"],[157,"Paraguay"],[158,"Peru"],[206,"Philippines"],[159,"Pitcairn Islands"],[160,"Poland"],[161,"Portugal"],[162,"Puerto Rico"],[93,"Qatar"],[163,"R&#233;union"],[165,"Romania"],[164,"Rwanda"],[169,"S&#227;o Tom&#233; and Pr&#237;ncipe"],[172,"Saint Helena"],[178,"Saint Kitts and Nevis"],[179,"Saint Lucia"],[180,"Saint Pierre and Miquelon"],[177,"Saint Vincent and the Grenadines"],[167,"Samoa"],[168,"San Marino"],[170,"Saudi Arabia"],[176,"Senegal"],[181,"Serbia"],[175,"Seychelles"],[190,"Sierra Leone"],[182,"Singapore"],[234,"Sint Maarten"],[184,"Slovakia"],[185,"Slovenia"],[186,"Solomon Islands"],[187,"Somalia"],[227,"South Africa"],[226,"South Korea"],[232,"South Sudan"],[87,"Spain"],[220,"Sri Lanka"],[188,"Sudan"],[189,"Suriname"],[219,"Svalbard and Jan Mayen"],[171,"Swaziland"],[218,"Sweden"],[217,"Switzerland"],[183,"Syria"],[192,"Taiwan"],[193,"Tanzania"],[191,"Thailand"],[194,"Togo"],[195,"Tokelau"],[196,"Tonga"],[197,"Trinidad and Tobago"],[199,"Tunisia"],[200,"Turkey"],[151,"Turks and Caicos Islands"],[198,"Tuvalu"],[53,"US Virgin Islands"],[201,"Uganda"],[145,"United Arab Emirates"],[49,"United Kingdom"],[203,"Uruguay"],[48,"Vanuatu"],[233,"Vatican"],[51,"Venezuela"],[55,"Vietnam"],[202,"Wallis and Futuna"],[78,"Western Sahara"],[89,"Yemen"],[77,"Zambia"],[79,"Zimbabwe"]],"country":""};

selectsData.setCountries(milFiltersel_data.countries);

uiMilCountry = new CountrySelect(ge('milCountry'), ge('cMilCountry'), {
  show: slide_show,
  hide: slide_hide,
  width: 150,
  country: milFiltersel_data.country,
  placeholder: 'Choose a country',
  zeroPlaceholder: true,
  placeholderColor: '#777',
  autocomplete: 1,
  noDefaultCountry: 1,
  full_list: 'Other Countries',
  onChange: function(value) {
    uiMilUnit.clear();
    if (intval(value)) {
      uiMilUnit.setURL('select_ajax.php?act=a_get_units&country=' + value);
      slide_show(ge('cMilUnit'));
    } else {
      slide_hide(ge('cMilUnit'));
    }
   searcher.updResults();
  }
});
uiMilUnit = new Selector(ge('milUnit'), 'select_ajax.php?act=a_get_units&country=' + encodeURIComponent(milFiltersel_data.country ? milFiltersel_data.country[0] : 0), {
  width: 150,
  minHeight: 250,
  multiselect: false,
  dropdown: false,
  introText: 'Enter a name',
  placeholder: 'Choose a branch',
  zeroPlaceholder: true,
  placeholderColor: '#777',
  noResult: 'No results found.',
  selectedItems: "",
  onChange: searcher.updResults
});

uiMilYear = new Dropdown(ge('milYearFrom'), [[0,"Year entered into service"],"2015","2014","2013","2012","2011","2010","2009","2008","2007","2006","2005","2004","2003","2002","2001","2000","1999","1998","1997","1996","1995","1994","1993","1992","1991","1990","1989","1988","1987","1986","1985","1984","1983","1982","1981","1980","1979","1978","1977","1976","1975","1974","1973","1972","1971","1970","1969","1968","1967","1966","1965","1964","1963","1962","1961","1960","1959","1958","1957","1956","1955","1954","1953","1952","1951","1950","1949","1948","1947","1946","1945"], {
  width: 150,
  selectedItems: '',
  zeroPlaceholder: true,
  placeholderColor: '#777',
  onChange: searcher.updResults
});

new Checkbox(ge('name'), {
  width: 150,
  label: 'Search in names only',
  onChange: searcher.updResults
});

legacyPlaceholderSetup('hometown');
addEvent('hometown', 'change keydown', searcher.onInputChange);

var uiBYear, uiBMonth, uiBDay;

function getDays(month, year) {
  var ret = [[0, 'Day of birth']], days = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31], daysCount = 31;

  if (month == '2' && year % 4 == 0) {
    daysCount = 29;
  } else if (month && days[month]){
    daysCount = days[month];
  }
  for (var i = 1; i <= daysCount; i++) {
    ret.push(i);
  }
  return ret;
}

var years = [[0, 'Year of birth']];
for (var i = 2001; i >= 1901; i--) {
  years.push(i);
}
var monthes = [[0, 'Month of birth'], [1, 'January'], [2, 'February'], [3, 'March'], [4, 'April'], [5, 'May'], [6, 'June'], [7, 'July'], [8, 'August'], [9, 'September'], [10, 'October'], [11, 'November'], [12, 'December']];

uiBYear = new Dropdown(ge('bYear'), years, {
  zeroPlaceholder: true,
  placeholderColor: '#777',
  width: 150,
  height: 170,
  selectedItem: '',
  onChange: function(value) {
    uiBDay.setData(getDays(uiBMonth.val(), value));
   searcher.updResults();
  }
});
uiBMonth = new Dropdown(ge('bMonth'), monthes, {
  zeroPlaceholder: true,
  placeholderColor: '#777',
  width: 150,
  height: 170,
  selectedItem: '',
  onChange: function(value) {
    uiBDay.setData(getDays(value, uiBYear.val()));
   searcher.updResults();
  }
});
uiBDay = new Dropdown(ge('bDay'), getDays('', ''), {
  zeroPlaceholder: true,
  placeholderColor: '#777',
  width: 150,
  height: 170,
  selectedItem: '',
  onChange: function(value) {
   searcher.updResults();
  }
});

var langsData = [[0,"Choose a language"],[-1,"�������"],[1,"���������"],[2,"���������� (��������i��)"],[3,"English"],[4,"Espa&#241;ol"],[5,"Suomi"],[6,"Deutsch"],[7,"Italiano"],[8,"���������"],[9,"Hrvatski"],[10,"Magyar"],[11,"������"],[12,"Portugu&#234;s"],[14,"&#917;&#955;&#955;&#951;&#957;&#953;&#954;&#940;"],[15,"Polski"],[16,"Fran&#231;ais"],[17,"&#54620;&#44397;&#50612;"],[18,"&#27721;&#35821;"],[19,"Lietuvi&#371;"],[20,"&#26085;&#26412;&#35486;"],[21,"&#268;e&#353;tina"],[22,"Eesti"],[23,"����������"],[50,"�������"],[51,"���&#1185;�����"],[52,"�&#259;�����"],[53,"Sloven&#269;ina"],[54,"Rom&#226;n&#259;"],[55,"Norsk"],[56,"Latvie&#353;u"],[57,"Az&#601;rbaycan dili"],[58,"&#1344;&#1377;&#1397;&#1381;&#1408;&#1381;&#1398;"],[59,"Shqip"],[60,"Svenska"],[61,"Nederlands"],[62,"T&#252;rkmen"],[63,"&#4325;&#4304;&#4320;&#4311;&#4323;&#4314;&#4312;"],[64,"Dansk"],[65,"O�zbek"],[66,"Moldoveneasc&#259;"],[67,"������"],[68,"&#3616;&#3634;&#3625;&#3634;&#3652;&#3607;&#3618;"],[69,"Bahasa Indonesia"],[70,"��&#1207;��&#1251;"],[71,"Sloven&#353;&#269;ina"],[72,"Bosanski"],[73,"Portugu&#234;s brasileiro"],[74,"&#1601;&#1575;&#1585;&#1587;&#1740;"],[75,"Ti&#7871;ng Vi&#7879;t"],[76,"&#2361;&#2367;&#2344;&#2381;&#2342;&#2368;"],[77,"&#3523;&#3538;&#3458;&#3524;&#3517;"],[78,"&#2476;&#2494;&#2434;&#2482;&#2494;"],[79,"Tagalog"],[80,"������"],[81,"&#4119;&#4121;&#4140;&#4101;&#4140;"],[82,"T&#252;rk&#231;e"],[83,"&#2344;&#2375;&#2346;&#2366;&#2354;&#2368;"],[84,"&#3749;&#3762;&#3751;"],[85,"&#1575;&#1585;&#1583;&#1608;"],[86,"Bahasa Melayu"],[87,"������ ����"],[88,"&#2350;&#2352;&#2366;&#2336;&#2368;"],[89,"&#2711;&#2753;&#2716;&#2736;&#2750;&#2724;&#2752; "],[90,"&#1662;&#1606;&#1580;&#1575;&#1576;&#1740;"],[91,"����"],[92,"&#2325;&#2379;&#2306;&#2325;&#2339;&#2368;"],[93,"&#6039;&#6070;&#6047;&#6070;&#6017;&#6098;&#6040;&#6082;&#6042;"],[94,"&#3221;&#3240;&#3277;&#3240;&#3233;"],[95,"Kiswahili"],[96,"&#2980;&#2990;&#3007;&#2996;&#3021;"],[97,"&#1178;���&#1179;��"],[98,"&#1575;&#1604;&#1593;&#1585;&#1576;&#1610;&#1577;"],[99,"&#1506;&#1489;&#1512;&#1497;&#1514;"],[101,"������ ����"],[102,"��������"],[103,"�&#1191;��� ����&#1241;�"],[104,"Q&#305;r&#305;mtatarca"],[105,"���� ����"],[106,"��������"],[107,"������"],[108,"����� �����"],[109,"���&#1216;���� ���&#1216;"],[110,"�I���I�� ����"],[111,"��������-������� ���"],[112,"������� ����"],[113,"�����"],[114,"����������"],[115,"Kurd&#238;"],[116,"&#1662;&#1690;&#1578;&#1608;"],[117,"����� �I��"],[118,"����� ����"],[119,"&#33274;&#28771;&#35441;"],[120,"&#4768;&#4635;&#4653;&#4763;"],[121,"����� ������"],[128,"����� ���"],[157,"Catal&#224;"],[168,"������ ���"],[193,"G&#227;"],[194,"Gagauz dili"],[230,"����� ��"],[236,"������� ���"],[237,"����� ���"],[253,"������� ����"],[279,"����� ����"],[298,"����������"],[327,"��������� �&#1216;��"],[344,"���� ���"],[345,"Uyghurche"],[357,"������ ����"],[372,"����������"],[375,"���� ���"],[376,"&#1329;&#1408;&#1381;&#1410;&#1396;&#1407;&#1377;&#1392;&#1377;&#1397;&#1381;&#1408;&#1383;&#1398;"],[386,"&#20013;&#25991; (&#32321;&#39636;)"],[388,"������"],[391,"I&#382;oran keeli"],[423,"Quenya"],[555,"Esperanto"],[666,"Lingua Latina"]];

uiLangs = new Dropdown(ge('lang'), langsData, {
  selectedItems: '',
  zeroPlaceholder: true,
  placeholderColor: '#777',
  width: 150,
  onChange: searcher.updResults
});cur.videoMarkSpam = function(link, oid, vid, hash) {
  var loadEl = ce('span', {className: 'loading'});
  ajax.post('/al_video.php', {act: 'video_mark_spam', vid: vid, oid: oid, hash: hash}, {
  onDone: function () {
    link.innerHTML = 'Video marked as spam.';
  },
  showProgress: function () {
    link.parentNode.replaceChild(loadEl, link);
  },
  hideProgress: function () {
    if (loadEl.parentNode) {
      loadEl.parentNode.replaceChild(link, loadEl);
    }
  }});
};

;(function (d, w) {
var ts = d.createElement("script"); ts.type = "text/javascript"; ts.async = true;
ts.src = (d.location.protocol == "https:" ? "https:" : "http:") + "//top-fwz1.mail.ru/js/code.js";
var f = function () {var s = d.getElementsByTagName("script")[0]; s.parentNode.insertBefore(ts, s);};
if (w.opera == "[object Opera]") { d.addEventListener("DOMContentLoaded", f, false); } else { f(); }
})(document, window);
    }
  </script>
</body>

</html>