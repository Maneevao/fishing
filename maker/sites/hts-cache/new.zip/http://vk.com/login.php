<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en" id="vkontakte">
<head>
<meta http-equiv="content-type" content="text/html; charset=windows-1251" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<title>Log in | VK</title>
<link rel="stylesheet" href="/css/rustyle.css?183" type="text/css" />
<script type="text/javascript">if (!window.vk) window.vk = {loginscheme: 'https', ip_h: '37fe515d56cd7fc4c1'};</script>
<script src="/js/common.js?309"></script>
<link rel="stylesheet" href="/css/reg.css?17" type="text/css" />
<link rel="stylesheet" href="/css/ui_controls.css?66" type="text/css" />
<script type="text/javascript" src="/js/lib/ui_controls.js?187"></script>
<script type="text/javascript" src="/js/lang3_0.js?3534"></script>
<link rel="stylesheet" href="/css/login.css?2" type="text/css" />
<meta name="robots" content="noindex" />

<link rel="shortcut icon" href="/images/favicon_vk.ico?3" />
<!--[if lte IE 6]><style type="text/css" media="screen">/* <![CDATA[ */ @import url(/css/ie.css?14); /* ]]> */</style><![endif]-->
<!--[if IE 7]><style type="text/css" media="screen">/* <![CDATA[ */ @import url(/css/ie7.css?14); /* ]]> */</style><![endif]-->
<!--[if gte IE 8]><style type="text/css" media="screen">/* <![CDATA[ */ @import url(/css/ie8.css); /* ]]> */</style><![endif]-->
<script type="text/javascript">
<!--
if (window.qArr && qArr[5]) qArr[5] = [5, "by item", "", "goods", 0x00000100];
onDomReady(function() {
  if (window.init_dec_hash) window.init_dec_hash();

  
  
if (1) {
  hide('support_link_td');
}
var ts_input = ge('ts_input'), oldFF = browser.mozilla && parseInt(browser.version) < 7;
if (browser.mozilla && !oldFF) {
  setStyle(ts_input, {padding: (window.is_rtl ? '3px 22px 4px 4px' : '3px 4px 4px 22px')});
}
placeholderSetup(ts_input, {back: false, reload: true});
if (browser.opera || browser.msie || oldFF) {
  setStyle(ts_input, {padding: (window.is_rtl ? '3px 22px 4px 4px' : '3px 4px 4px 22px')});
}
TopSearch.init();
if (browser.msie8 || browser.msie7) {
  var st = {border: '1px solid #a6b6c6'};
  if (hasClass(ge('ts_wrap'), 'vk')) {
    if (window.is_rtl) st.left = '1px';
    else st.right = '1px';
  } else {
    if (window.is_rtl) st.right = '146px';
    else st.left = '146px';
  }
  setStyle(ge('ts_cont_wrap'), st);
}
window.tsHintsEnabled = 1;
});



var base_domain = '/';
css_versions = extend(css_versions, {
  lib_ui_controls_js: 187,
  ui_controls_css: 66,

  mentions_js: 50,
  qsearch_js: 34,
  privacy_css: 26,
  wiki_css: 29,
  gifts_css: 59
});

var is_rtl = false;if (parent && parent != window && (browser.msie || browser.opera || browser.mozilla || browser.chrome || browser.safari || browser.iphone)) {
  onDomReady(function() {
    document.getElementsByTagName('body')[0].innerHTML = '<h1 style="color: #F00">THIS IS NOT VKONTAKTE AND NOT VK SITE</h1>';
  });
}
window.awayHash = '92cc5fe0ceb217bed5';

//-->
</script>
</head>

<body class="pads" onresize="onBodyResize()">
<div id="pageContainer">




 <div id="pageLayout">

<script type="text/javascript">onBodyResize()</script>

<!-- pageHeader -->

  <div id="pageHeader" class="p_head1 p_head_l3">
   <div class="header_back"></div>
   <div class="header_left"></div>
   <div class="header_right"></div>
   <div id="pageHeaderRight">


   <h1 id="home"><div id="top_logo_down"></div><a class="top_home_link" href="/" onmousedown="addClass('top_logo_down','tld_d');">���������</a></h1>

<div id="topNav" class="headNav">
  <div id="topLinks">
  </div>
</div>
<div class="headNav">
</div>

   </div>
  </div>

<!-- End pageHeader -->

<!-- sideBar -->

  <div id="sideBar">

   
<ol id='nav'>
  <li><a href='/index.php'>Home</a></li>
  <li><a href='/login.php'>Log in</a></li>
  <li><a href='/reg0'>Sign up</a></li>
</ol>

   
  </div>

<!-- End sideBar -->

<!-- pageBody -->

  <div id="pageBody" class="pageBody">
  <div id="wrapH">
  <div id="wrapHI">
   <div id="header"><h1> Log in</h1></div>
  </div>
  </div>

  <div id="wrap2">
  <div id="wrap1">
   <div id="content">

    <script type="text/javascript">
var vklogin = false;
function try_to_login(obj, text) {
  if (text.substr(0, 4) == 'good') {
    var to = '';
    if (location.hash.toString().length) {
      to += location.hash;
    }
    if (to.length) {
      window.location.href = '/' + to;
    } else {
      window.location.href = '/id' + text.substr(4);
    }
  } else if (text.substr(0, 10) == 'not_active') {
    window.location.href = '/login.php?r=1';
  } else if (text.substr(0, 6) == 'invite') {
    window.location.href = '/help.php?page=welcome&hash=' + text.substr(6);
  } else if (text.substr(0, 9) == 'reginvite') {
    window.location.href = '/register.php?hash=' + text.substr(9);
  } else if (text.substr(0, 7) == 'vklogin') {
    vklogin = true;
    ge('login').submit();
  } else {
    show('message_text');
    ge('message_text').innerHTML = "<div id='error' style='font-size: 11px'>Invalid login or password.</div>";
  }
}

function quick_login() {
  var options = {onSuccess: try_to_login};
  hide('message_text');
  Ajax.postWithCaptcha('/login.php', {'op': 'a_login_attempt', 'login': ge('email').value}, options);
}

var captcha_send = 'Send';
var captcha_cancel = 'Cancel';

function showFastRestoreRows(el) {
  while (el.tagName != 'TR') el = domPN(el);
  hide(el);
  for (var i = 0; i < 5; ++i) {
    toggle(el = domNS(el), (i != 2));
  }
  focusAtEnd('fast_restore_phone');
}

function showPhoneTT() {
  hideCodeTT(true);
  hidePhoneTT(true);

  animate(ge('fast_phone_tt'), window.is_rtl ? {opacity: 1, marginRight: 172} : {opacity: 1, marginLeft: 172}, 200);
}
function hideTT(el, fast) {
  if (fast === true) {
    var anim = data(el, 'tween');
    if (anim) anim.stop();
    setStyle(el, window.is_rtl ? {opacity: 0, marginRight: 182} : {opacity: 0, marginLeft: 182});
  } else {
    animate(el, {opacity: 0}, 200, hidePhoneTT.pbind(true));
  }
}
function hidePhoneTT(fast) {
  hideTT(ge('fast_phone_tt'), fast);
}
function showCodeTT() {
  hideCodeTT(true);
  hidePhoneTT(true);
  animate(ge('fast_code_tt'), window.is_rtl ? {opacity: 1, marginRight: 172} : {opacity: 1, marginLeft: 172}, 200);
}
function hideCodeTT(fast) {
  hideTT(ge('fast_code_tt'), fast);
}
var sentPhone = false, restoreCode = false, resendInt = false, resendDelay = false;
function fastRestoreCheck() {
  if (sentPhone !== false) {
    if (ge('fast_restore_phone').value == sentPhone) {
      show(ge('fast_restore_code_row'), ge('fast_restore_resend'));
    } else {
      hide(ge('fast_restore_code_row'), ge('fast_restore_resend'));
      if (resendInt) {
        clearInterval(resendInt);
      }
    }
  }
}
function fastRestoreResendUpdate() {
  if (resendDelay > 0) {
    ge('fast_restore_resend').innerHTML = 'Resend the code in %s'.replace('%s', Math.floor(resendDelay / 60) + ':' + (resendDelay % 60 < 10 ? '0' : '') + (resendDelay % 60));
    resendDelay--;
  } else {
    ge('fast_restore_resend').innerHTML = '<a onclick="fastRestoreResend(this);">Resend the code</a>';
    clearInterval(resendInt);
  }
}
function fastRestoreResend(el) {
  var phone = ge('fast_restore_phone').value;
  if (domPN(el)) {
    domPN(el).replaceChild(ce('div', {className: 'progress fl_l', id: 'fast_restore_resend_prg'}, {margin: '6px 10px'}), el);
    show('fast_restore_resend_prg');
  }
  Ajax.postWithCaptcha('login.php?act=fast_restore_resend', {phone: phone, restore: restoreCode}, {
    onSuccess: function(obj, text) {
      var e = ge('fast_restore_resend_prg');
      if (e) {
        domPN(e).replaceChild(el, e);
      }
      var res = eval('(' + text + ')');
      var err = ge('fast_restore_error');
      if (res.error) {
        err.innerHTML = res.error;
        if (!isVisible(err)) {
          show(err);
        } else {
          animate(err, {backgroundColor: '#F4EBBD'}, 100, animate.pbind(err, {backgroundColor: '#F9F6E7'}, 2000));
        }
        notaBene(ge('fast_restore_code'));
      } else if (res.result_text) {
        domPN(el).replaceChild(ce('div', {className: 'fl_l', innerHTML: res.result_text}, {color: '#777777'}), el);
        setTimeout(focusAtEnd.pbind(ge('fast_restore_code')), 0);
      }
    },
    onCaptchaShow: function() {
      var e = ge('fast_restore_resend_prg');
      if (e) {
        domPN(e).replaceChild(el, e);
      }
    }
  });
}
function fastRestore(ev) {
  ev = ev || window.event;
  if (ev && (ev.keyCode !== undefined) && (ev.type != 'click')) {
    if (ev.keyCode !== KEY.ENTER) {
      return;
    }
    if (ev.target == ge('fast_restore_phone') && isVisible(ge('fast_restore_code_row'))) {
      focusAtEnd(ge('fast_restore_code'));
      return cancelEvent(ev);
    }
  }
  var btn = ge('fast_restore_btn'), phone = ge('fast_restore_phone').value, code;
  if (phone.replace(/[^0-9]/g, '').length < 8) {
    focusAtEnd(ge('fast_restore_phone'));
    notaBene(ge('fast_restore_phone'));
    return cancelEvent(ev);
  }
  lockButton(btn);
  if (isVisible(ge('fast_restore_code_row'))) {
    code = ge('fast_restore_code').value;
    if (code.replace(/[^0-9a-z]/g, '').length < 4) {
      focusAtEnd(ge('fast_restore_code'));
      notaBene(ge('fast_restore_code'));
      return cancelEvent(ev);
    }
    Ajax.postWithCaptcha('login.php?act=fast_restore_code', {phone: phone, code: code, restore: restoreCode}, {
      onSuccess: function(obj, text) {
        var res = eval('(' + text + ')');
        unlockButton(btn);
        var err = ge('fast_restore_error');
        if (res.error) {
          err.innerHTML = res.error;
          if (!isVisible(err)) {
            show(err);
          } else {
            animate(err, {backgroundColor: '#F4EBBD'}, 100, animate.pbind(err, {backgroundColor: '#F9F6E7'}, 2000));
          }
          notaBene(ge('fast_restore_code'));
        } else if (res.success) {
          location.href = 'https://login.vk.com/?act=fast_restored&code=' + restoreCode + '&_origin=' + encodeURIComponent(location.protocol + '//' + location.host);
        }
      },
      onCaptchaShow: function() {
        unlockButton(btn);
      }
    });
  } else {
    Ajax.postWithCaptcha('login.php?act=fast_restore', {phone: phone, hash: '01c726a2685a3c28fb'}, {
      onSuccess: function(obj, text) {
        var res = eval('(' + text + ')');
        if (res.reload) {
          location.reload(true);
          return;
        }
        if (res.wait) {
          setTimeout(fastRestore.pbind(false), 1000);
          return;
        }
        unlockButton(btn);
        var err = ge('fast_restore_error');
        if (res.error) {
          err.innerHTML = res.error;
          if (!isVisible(err)) {
            show(err);
          } else {
            animate(err, {backgroundColor: '#F4EBBD'}, 100, animate.pbind(err, {backgroundColor: '#F9F6E7'}, 2000));
          }
          notaBene(ge('fast_restore_phone'));
        } else {
          restoreCode = res.restore;
          hide(err);
          sentPhone = phone;
          show(ge('fast_restore_code_row'), ge('fast_restore_resend'));
          setTimeout(focusAtEnd.pbind(ge('fast_restore_code')), 0);
          resendDelay = 60;
          resendInt = setInterval(fastRestoreResendUpdate, 1000);
          if (res.notice) {
            err.innerHTML = res.notice;
            if (!isVisible(err)) {
              show(err);
            } else {
              animate(err, {backgroundColor: '#F4EBBD'}, 100, animate.pbind(err, {backgroundColor: '#F9F6E7'}, 2000));
            }
          }
        }
      },
      onCaptchaShow: function() {
        unlockButton(btn);
      }
    });
  }
  return cancelEvent(ev);
}
</script>

<div id="message_text">

</div>

<div class="simplePage" style="padding: 15px 0px 0px">
  <form method="post" name="login" id="login" action="https://login.vk.com/" onsubmit="if (vklogin) { return true} else { quick_login();return false;}">
    <input type="hidden" name="act" id="act" value="login">
    <input type="hidden" name="to" id="to" value=""/>
    <input type="hidden" name="_origin" value="http://vk.com" />
    <input type="hidden" name="ip_h" value="37fe515d56cd7fc4c1" />
    <input type="hidden" name="lg_h" value="4a1cead1d4305b44d2" />

    <table align="center" cellpadding="0" cellspacing="0" border="0" width="100%">
      <tr>
        <td class="ta_r log_label"><span class="grey">Phone or email</span></td>
        <td style="padding: 0px">
          <input class="inputText" type="text" name="email" value="" id="email" style="width: 152px; margin: 0px"/>
        <td>
      </tr>
      <tr>
        <td class="ta_r log_label"><span class="grey">Password</span></td>
        <td style="padding: 0px">
          <input class="inputText" type="password" name="pass" value="" id="pass" style="width: 152px; margin: 0px"/>
        </td>
      </tr>
      <tr>
        <td class="ta_r log_label">&nbsp;</td>
        <td>
          <input type="hidden" name="expire" id="expire" />
<script type="text/javascript">
onDomReady(function() {
  new Checkbox(ge('expire'), {
    width: 150,
    label: 'Don&#39;t remember me'
  });
  focusAtEnd(ge('email').value ? ge('pass') : ge('email'));
  if (ge('fast_restore_btn')) {
    ge('fast_restore_btn').parentNode.appendChild(ce('div', {innerHTML: '<iframe name="fast_restore_test_frame"></iframe><form id="fast_restore_test_form" method="POST" action="https://login.vk.com/?act=create_test&_origin=http://vk.com&' + Math.random() + '" target="fast_restore_test_frame"></form>'}, {position: 'absolute', visibility: 'hidden'}));
    ge('fast_restore_test_form').submit();
  }
});
</script>
        </td>
      </tr>
      <tr>
        <td class="ta_r log_label">&nbsp;</td>
        <td><div style="height:20px; margin:5px 0px">
<button class="flat_button" onclick="quick_login();return cancelEvent(event);">Log in</button><span class="divide">&nbsp;</span><a href="/join"><button class="flat_button" onclick="location.href='/join';return cancelEvent(event);">Sign up</button></a>
        </div></td>
      </tr>
    </table>
    <input type="submit" value='.' style="color:#fff;border:0;padding:0;margin:0;background:#fff;height:6px;width:6px" />
  </form>
  <div class="login_restore">
    <div class="login_msg" id="fast_restore_error" style="display: none"></div>
    <table align="center" cellpadding="0" cellspacing="0" border="0" width="100%">
      <tr><td class="ta_r log_label">&nbsp;</td><td><a onclick="showFastRestoreRows(this)">Forgot your password or cannot log in?</a></td></tr><tr style="display: none">
  <td class="ta_r log_label">&nbsp;</td>
  <td>
    <div id="fast_restore_h">Instant password retrieval</div>
  </td>
</tr>
<tr style="display: none">
  <td class="ta_r log_label"><span class="grey">Phone number:</span></td>
  <td>
    <div style="padding: 0px 0px 0px">
      <input type="text" class="inputText" onfocus="showPhoneTT()" onblur="hidePhoneTT()" id="fast_restore_phone" value="+7" style="width: 152px" onkeypress="return fastRestore(event)" onkeydown="setTimeout(fastRestoreCheck, 0)" />
    </div>
    <div class="fast_tt" id="fast_phone_tt"><table cellspacing="0" cellpadding="0">
      <tr><td><table cellspacing="0" cellpadding="0">
        <tr><td class="fast_tt_wrap"><div class="fast_tt_text"><div class="fast_tt_pointer"></div>
          Phone number linked to your page.<br><br>Example: +1 000 0000000
        </div></td></tr>
        <tr><td><div class="fast_tt_bottom_sh1"></div></td></tr>
      </table></td></tr>
      <tr><td><div class="fast_tt_bottom_sh2"></div></td></tr>
    </table></div>
  </td>
</tr>
<tr id="fast_restore_code_row" style="display: none">
  <td class="ta_r log_label"><span class="grey">Activation code:</span></td>
  <td>
    <div style="padding: 0px 0px 0px">
      <input type="text" class="inputText" onfocus="showCodeTT()" onblur="hideCodeTT()" id="fast_restore_code" onkeypress="return fastRestore(event)" style="width: 152px" />
    </div>
    <div class="fast_tt" id="fast_code_tt"><table cellspacing="0" cellpadding="0">
      <tr><td><table cellspacing="0" cellpadding="0">
        <tr><td class="fast_tt_wrap"><div class="fast_tt_text"><div class="fast_tt_pointer"></div>
          You will receive an activation code to your phone within seconds.<br><br>Code example: <b>e3np11</b>
        </div></td></tr>
        <tr><td><div class="fast_tt_bottom_sh1"></div></td></tr>
      </table></td></tr>
      <tr><td><div class="fast_tt_bottom_sh2"></div></td></tr>
    </table></div>
  </td>
</tr>
<tr style="display: none">
  <td class="ta_r log_label">&nbsp;</td>
  <td>
    <div style="height: 20px; margin: 10px 0;">
      <div class="fl_l" style="width: 160px;">
        <button id="fast_restore_btn" class="flat_button button_wide" onclick="return fastRestore()">Restore access</button>
      </div>
      <div id="fast_restore_resend" class="fl_l" style="margin: 6px 10px; color: #777; display: none;">
        Resend the code in 1:00
      </div>
    </div>
  </td>
</tr>
<tr style="display: none">
  <td class="ta_r log_label">&nbsp;</td>
  <td><a href="/restore">My page is not linked to a phone</a></td>
</tr>
    </table>
  </div>
</div>


   </div>
  </div>
  </div>
  

  </div>
  <div id="boxHolder"></div>

<!-- End pageBody -->

<!-- bFooter -->
<div id="bFooter">
 <ul class="bNav2">
  <li><a href="/about">about</a></li>
  <li><a href="/support?act=new">help</a></li>
  <li><a href="/terms">terms</a></li>
  <li><a href="/dev">developers</a></li>
 </ul>
</div>
<div class="footerVK">
 <div><a href="/about">VK</a> &copy; 2015 <a href="#" onclick="return doChangeLang(3, '5dccc60b57cc1ebda7');" style="margin-left:7px">English</a><a href="#" onclick="return doChangeLang(0, '5dccc60b57cc1ebda7');" style="margin-left:7px">�������</a><a href="#" onclick="return doChangeLang(1, '5dccc60b57cc1ebda7');" style="margin-left:7px">���������</a><a href="#" onclick="return changeLang();" class="langSelector">all languages �</a></div>
 <div><!----></div>
</div>
<!--Both counters-->
<script type="text/javascript">
<!--
onDomReady(function(){
  setTimeout(function() {
    (new Image()).src = 'http://counter.yadro.ru/hit?r' + escape(document.referrer) + ((typeof(screen)=='undefined')?'':';s'+screen.width+'*'+screen.height+'*'+(screen.colorDepth?screen.colorDepth:screen.pixelDepth)) + ';u' + escape(document.URL) + ';' + Math.random() + '';
  }, 10);
});
//-->
</script>
<!--/Both counters-->
<!-- End bFooter -->

</div>

<script type="text/javascript">
window.init_dec_hash = function() {
  window.decoded_hashes = {};
  var dec_hash = function(hash) {
    (function(_){window.decoded_hashes[_]=(function(__){var ___=ge?'':'___';for(____=0;____<__.length;++____)___+=__.charAt(__.length-____-1);return geByClass?___:'___';})(_.substr(_.length-5)+_.substr(4,_.length-12));})(hash);
  }
  window.decodehash = function(hash) {
    dec_hash(hash);
    return window.decoded_hashes[hash];
  }
}
</script>



<!-- End pageLayout 304314 -->
</div>
</body>
</html>
